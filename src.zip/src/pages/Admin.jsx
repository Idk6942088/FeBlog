import React from 'react'


export const Admin = () => {
  return (
    <div>
      default Admin
    </div>
  )
}

