export const firebaseConfig = {
  apiKey: "AIzaSyBv9G1B-JJrtDNw0WOBDYFmn8ZeAyAFrDY",
  authDomain: "myblog-5c625.firebaseapp.com",
  projectId: "myblog-5c625",
  storageBucket: "myblog-5c625.firebasestorage.app",
  messagingSenderId: "144408343896",
  appId: "1:144408343896:web:7f71a9cb30c498afd4212d"
};